const correct = { A:3, B:5, C:7, D:1, E:8, F:2, G:4, H:6 };
const numbersDiv = document.getElementById("numbers");
const successSound = document.getElementById("successSound");
const failSound = document.getElementById("failSound");
const resetBtn = document.getElementById("resetBtn");

let moves = 0;
let tries = 3;
let timer = 0;
let timerInterval;
let gameLocked = false;

// ---- Create draggable numbers ----
function createNumbers() {
  numbersDiv.innerHTML = "";
  for (let i = 1; i <= 8; i++) {
    const num = document.createElement("div");
    num.textContent = i;
    num.className = "number";
    num.draggable = true;
    num.id = "num" + i;
    num.addEventListener("dragstart", (e) => e.dataTransfer.setData("text/plain", i));
    numbersDiv.appendChild(num);
  }
}

// ---- Enable dropping on grid cells ----
function setupGrid() {
  document.querySelectorAll(".cell[data-cell]").forEach((cell) => {
    cell.textContent = "";
    cell.dataset.value = "";
    cell.classList.remove("success", "fail");
    cell.addEventListener("dragover", (e) => e.preventDefault());
    cell.addEventListener("dragenter", () => cell.classList.add("drop-hover"));
    cell.addEventListener("dragleave", () => cell.classList.remove("drop-hover"));
    cell.addEventListener("drop", (e) => {
      if (gameLocked) return;
      e.preventDefault();
      const num = e.dataTransfer.getData("text/plain");
      cell.classList.remove("drop-hover");
      cell.textContent = num;
      cell.dataset.value = num;
      moves++;
      updateInfo();
      checkGame();
    });
  });
}

// ---- Timer ----
function startTimer() {
  clearInterval(timerInterval);
  timer = 0;
  timerInterval = setInterval(() => {
    timer++;
    document.getElementById("timer").textContent = ⏱ ${Math.floor(timer / 60)}:${String(timer % 60).padStart(2, "0")};
  }, 1000);
}

// ---- Update move + tries info ----
function updateInfo() {
  document.getElementById("moves").textContent = Moves: ${moves};
  document.getElementById("tries").textContent = Tries left: ${tries};
}

// ---- Confetti animation ----
function confettiBurst() {
  confetti({
    particleCount: 150,
    spread: 70,
    origin: { y: 0.6 },
  });
}

// ---- Check correctness ----
function checkGame() {
  const all = document.querySelectorAll(".cell[data-cell]");
  const filled = [...all].every((c) => c.dataset.value);
  if (!filled) return;

  let correctCount = 0;
  all.forEach((c) => {
    const key = c.dataset.cell;
    const val = parseInt(c.dataset.value);
    if (correct[key] === val) {
      c.classList.add("success");
      correctCount++;
    } else {
      c.classList.add("fail");
    }
  });

  if (correctCount === 8) {
    successSound.play();
    confettiBurst();
    clearInterval(timerInterval);
    alert(🎉 You solved it perfectly in ${moves} moves and ${timer}s!);
    gameLocked = true;
  } else {
    failSound.play();
    tries--;
    updateInfo();

    if (tries > 0) {
      alert(❌ Wrong placement! Try again. (${tries} tries left));
      setTimeout(() => {
        all.forEach((c) => {
          if (c.classList.contains("fail")) {
            c.textContent = "";
            c.dataset.value = "";
            c.classList.remove("fail");
          }
        });
      }, 1000);
    } else {
      alert("😢 No tries left! Let another player try!");
      gameLocked = true;
      clearInterval(timerInterval);
    }
  }
}

// ---- Reset ----
resetBtn.addEventListener("click", () => {
  clearInterval(timerInterval);
  moves = 0;
  tries = 3;
  gameLocked = false;
  createNumbers();
  setupGrid();
  startTimer();
  updateInfo();
});

createNumbers();
setupGrid();
startTimer();
updateInfo();