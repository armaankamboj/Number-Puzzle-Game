import { Button } from "@/components/ui/button";
import { XCircle } from "lucide-react";

interface GameOverModalProps {
  isOpen: boolean;
  onTryAgain: () => void;
}

export default function GameOverModal({ isOpen, onTryAgain }: GameOverModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-card-border rounded-2xl p-8 max-w-md w-full shadow-2xl" data-testid="gameover-modal">
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <XCircle className="w-20 h-20 text-destructive" />
          </div>
          
          <div>
            <h2 className="text-3xl font-bold mb-2">Out of Lives!</h2>
            <p className="text-muted-foreground">Don't give up! Try again and solve the puzzle.</p>
          </div>

          <Button 
            onClick={onTryAgain}
            className="w-full"
            size="lg"
            data-testid="button-try-again"
          >
            Try Again
          </Button>
        </div>
      </div>
    </div>
  );
}
