import { cn } from "@/lib/utils";
import { Check, X } from "lucide-react";

interface Cell {
  id: string;
  value: number | null;
  isCorrect?: boolean;
  isIncorrect?: boolean;
}

interface PuzzleGridProps {
  cells: Cell[];
  onDrop: (cellId: string, value: number, sourceCellId?: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragStart: (e: React.DragEvent, cellId: string, value: number) => void;
  gameLocked: boolean;
}

export default function PuzzleGrid({ cells, onDrop, onDragOver, onDragStart, gameLocked }: PuzzleGridProps) {
  const handleDrop = (e: React.DragEvent, cellId: string) => {
    if (gameLocked) return;
    e.preventDefault();
    const value = parseInt(e.dataTransfer.getData("text/plain"));
    const sourceCellId = e.dataTransfer.getData("sourceCellId") || undefined;
    onDrop(cellId, value, sourceCellId);
    e.currentTarget.classList.remove("ring-2", "ring-primary");
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.add("ring-2", "ring-primary");
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.currentTarget.classList.remove("ring-2", "ring-primary");
  };

  return (
    <div className="grid grid-cols-4 gap-3 md:gap-4 max-w-md md:max-w-lg mx-auto">
      {cells.map((cell, index) => {
        const isEmpty = cell.id === "empty";
        
        return (
          <div
            key={index}
            data-testid={isEmpty ? undefined : `cell-${cell.id}`}
            draggable={!isEmpty && cell.value !== null && !gameLocked && !cell.isCorrect && !cell.isIncorrect}
            className={cn(
              "aspect-square rounded-xl flex items-center justify-center text-3xl md:text-4xl font-bold transition-all duration-200",
              isEmpty && "invisible",
              !isEmpty && !cell.value && "border-2 border-dashed border-cyan-400/60 bg-cyan-50/30 dark:bg-cyan-950/20 hover:bg-cyan-100/40 dark:hover:bg-cyan-900/30 hover:scale-105 hover:border-cyan-500",
              !isEmpty && cell.value && !cell.isCorrect && !cell.isIncorrect && "bg-white dark:bg-gray-800 border-2 border-cyan-300 dark:border-cyan-700 shadow-lg cursor-grab active:cursor-grabbing",
              cell.isCorrect && "bg-green-500 text-white animate-pulse-scale border-green-600",
              cell.isIncorrect && "bg-destructive text-destructive-foreground animate-shake border-destructive"
            )}
            onDrop={(e) => !isEmpty && handleDrop(e, cell.id)}
            onDragOver={!isEmpty ? onDragOver : undefined}
            onDragEnter={!isEmpty ? handleDragEnter : undefined}
            onDragLeave={!isEmpty ? handleDragLeave : undefined}
            onDragStart={(e) => !isEmpty && cell.value && onDragStart(e, cell.id, cell.value)}
          >
            {cell.value && (
              <div className="relative">
                <span>{cell.value}</span>
                {cell.isCorrect && (
                  <Check className="absolute -top-2 -right-2 w-5 h-5" />
                )}
                {cell.isIncorrect && (
                  <X className="absolute -top-2 -right-2 w-5 h-5" />
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
