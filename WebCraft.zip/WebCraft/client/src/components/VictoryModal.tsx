import { Button } from "@/components/ui/button";
import { Trophy, Clock, Move } from "lucide-react";

interface VictoryModalProps {
  isOpen: boolean;
  timer: number;
  moves: number;
  onPlayAgain: () => void;
}

export default function VictoryModal({ isOpen, timer, moves, onPlayAgain }: VictoryModalProps) {
  if (!isOpen) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-card-border rounded-2xl p-8 max-w-md w-full shadow-2xl" data-testid="victory-modal">
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <Trophy className="w-20 h-20 text-amber-400 animate-pulse-scale" />
          </div>
          
          <div>
            <h2 className="text-3xl font-bold mb-2">Congratulations!</h2>
            <p className="text-muted-foreground">You solved the puzzle perfectly!</p>
          </div>

          <div className="bg-primary/10 rounded-xl p-6 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="w-5 h-5" />
                <span>Time</span>
              </div>
              <span className="font-mono font-bold text-xl">{formatTime(timer)}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Move className="w-5 h-5" />
                <span>Moves</span>
              </div>
              <span className="font-bold text-xl">{moves}</span>
            </div>
          </div>

          <Button 
            onClick={onPlayAgain}
            className="w-full"
            size="lg"
            data-testid="button-play-again"
          >
            Play Again
          </Button>
        </div>
      </div>
    </div>
  );
}
