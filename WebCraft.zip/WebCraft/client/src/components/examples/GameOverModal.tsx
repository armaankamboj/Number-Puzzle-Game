import GameOverModal from "../GameOverModal";

export default function GameOverModalExample() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500">
      <GameOverModal
        isOpen={true}
        onTryAgain={() => console.log("Try again clicked")}
      />
    </div>
  );
}
