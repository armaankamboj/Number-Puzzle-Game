import GameStats from "../GameStats";

export default function GameStatsExample() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-8">
      <GameStats timer={125} moves={42} lives={2} />
    </div>
  );
}
