import VictoryModal from "../VictoryModal";

export default function VictoryModalExample() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500">
      <VictoryModal
        isOpen={true}
        timer={185}
        moves={56}
        onPlayAgain={() => console.log("Play again clicked")}
      />
    </div>
  );
}
