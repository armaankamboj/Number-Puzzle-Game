import NumberPalette from "../NumberPalette";

export default function NumberPaletteExample() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-8">
      <NumberPalette
        numbers={[1, 2, 3, 4, 5, 6, 7, 8]}
        usedNumbers={[1, 5, 8]}
        onDragStart={(e, num) => console.log(`Dragging number ${num}`)}
        gameLocked={false}
      />
    </div>
  );
}
