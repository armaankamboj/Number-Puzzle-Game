import PuzzleGrid from "../PuzzleGrid";

export default function PuzzleGridExample() {
  const mockCells = [
    { id: "empty", value: null },
    { id: "A", value: null },
    { id: "B", value: 5 },
    { id: "empty", value: null },
    { id: "C", value: null },
    { id: "D", value: 1, isCorrect: true },
    { id: "E", value: null },
    { id: "F", value: null },
    { id: "empty", value: null },
    { id: "G", value: 9, isIncorrect: true },
    { id: "H", value: null },
    { id: "empty", value: null },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-8">
      <PuzzleGrid
        cells={mockCells}
        onDrop={(cellId, value, sourceCellId) => console.log(`Dropped ${value} on ${cellId} from ${sourceCellId || 'palette'}`)}
        onDragOver={(e) => e.preventDefault()}
        onDragStart={(e, cellId, value) => console.log(`Dragging ${value} from ${cellId}`)}
        gameLocked={false}
      />
    </div>
  );
}
