import { Clock, Move, Heart } from "lucide-react";
import { cn } from "@/lib/utils";

interface GameStatsProps {
  timer: number;
  moves: number;
  lives: number;
}

export default function GameStats({ timer, moves, lives }: GameStatsProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex items-center justify-center gap-6 md:gap-8 p-4 bg-card/50 backdrop-blur-sm rounded-xl border border-card-border max-w-md mx-auto">
      <div className="flex items-center gap-2" data-testid="timer">
        <Clock className="w-5 h-5 text-primary" />
        <span className="font-mono font-semibold text-lg">{formatTime(timer)}</span>
      </div>
      
      <div className="w-px h-6 bg-border" />
      
      <div className="flex items-center gap-2" data-testid="moves">
        <Move className="w-5 h-5 text-primary" />
        <span className="font-medium text-lg">{moves}</span>
      </div>
      
      <div className="w-px h-6 bg-border" />
      
      <div className="flex items-center gap-2" data-testid="lives">
        <Heart className={cn("w-5 h-5", lives > 0 ? "text-destructive fill-destructive" : "text-muted-foreground")} />
        <span className="font-medium text-lg">{lives}</span>
      </div>
    </div>
  );
}
