import { cn } from "@/lib/utils";

interface NumberPaletteProps {
  numbers: number[];
  usedNumbers: number[];
  onDragStart: (e: React.DragEvent, num: number) => void;
  gameLocked: boolean;
}

export default function NumberPalette({ numbers, usedNumbers, onDragStart, gameLocked }: NumberPaletteProps) {
  return (
    <div className="flex flex-wrap justify-center gap-3 max-w-md mx-auto">
      {numbers.map((num) => {
        const isUsed = usedNumbers.includes(num);
        
        return (
          <div
            key={num}
            data-testid={`number-${num}`}
            draggable={!isUsed && !gameLocked}
            onDragStart={(e) => !isUsed && !gameLocked && onDragStart(e, num)}
            className={cn(
              "w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center text-xl md:text-2xl font-bold transition-all duration-200",
              !isUsed && !gameLocked && "bg-amber-400 text-amber-900 cursor-grab active:cursor-grabbing hover:scale-110 active:scale-95 shadow-md hover:shadow-lg",
              isUsed && "bg-muted/30 text-muted-foreground/30 cursor-not-allowed",
              gameLocked && "cursor-not-allowed"
            )}
          >
            {num}
          </div>
        );
      })}
    </div>
  );
}
