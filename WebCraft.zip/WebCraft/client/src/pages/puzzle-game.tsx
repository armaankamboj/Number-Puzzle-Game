import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { RotateCcw } from "lucide-react";
import PuzzleGrid from "@/components/PuzzleGrid";
import NumberPalette from "@/components/NumberPalette";
import GameStats from "@/components/GameStats";
import VictoryModal from "@/components/VictoryModal";
import GameOverModal from "@/components/GameOverModal";
import logoImage from "@assets/sfslogo_1762188635263.jpg";

const CORRECT_SEQUENCE: Record<string, number> = {
  A: 3,
  B: 5,
  C: 7,
  D: 1,
  E: 8,
  F: 2,
  G: 4,
  H: 6,
};

const CELL_IDS = ["empty", "A", "B", "empty", "C", "D", "E", "F", "empty", "G", "H", "empty"];

declare global {
  interface Window {
    confetti: any;
  }
}

export default function PuzzleGame() {
  const [cells, setCells] = useState(
    CELL_IDS.map((id) => ({ id, value: null, isCorrect: false, isIncorrect: false }))
  );
  const [moves, setMoves] = useState(0);
  const [lives, setLives] = useState(3);
  const [timer, setTimer] = useState(0);
  const [gameLocked, setGameLocked] = useState(false);
  const [showVictory, setShowVictory] = useState(false);
  const [showGameOver, setShowGameOver] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const successAudioRef = useRef<HTMLAudioElement | null>(null);
  const failAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    successAudioRef.current = new Audio("https://actions.google.com/sounds/v1/cartoon/clang_and_wobble.ogg");
    failAudioRef.current = new Audio("https://actions.google.com/sounds/v1/cartoon/wood_plank_flicks.ogg");

    timerRef.current = setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const playConfetti = () => {
    if (typeof window !== "undefined" && window.confetti) {
      window.confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const checkGame = (updatedCells: typeof cells) => {
    const filledCells = updatedCells.filter((c) => c.id !== "empty");
    const allFilled = filledCells.every((c) => c.value !== null);

    if (!allFilled) return;

    // Check if all cells are correct
    let correctCount = 0;
    filledCells.forEach((cell) => {
      if (CORRECT_SEQUENCE[cell.id] === cell.value) {
        correctCount++;
      }
    });

    if (correctCount === 8) {
      // Victory! Show the correct positions with green
      const newCells = updatedCells.map((cell) => {
        if (cell.id === "empty") return cell;
        return {
          ...cell,
          isCorrect: true,
          isIncorrect: false,
        };
      });
      setCells(newCells);
      
      successAudioRef.current?.play();
      playConfetti();
      if (timerRef.current) clearInterval(timerRef.current);
      setGameLocked(true);
      setTimeout(() => setShowVictory(true), 500);
    } else {
      // Wrong answer - don't reveal which are correct, just reset the grid
      failAudioRef.current?.play();
      const newLives = lives - 1;
      setLives(newLives);

      if (newLives > 0) {
        // Reset the entire grid after a brief pause
        setTimeout(() => {
          setCells((prev) =>
            prev.map((cell) => ({
              ...cell,
              value: null,
              isCorrect: false,
              isIncorrect: false
            }))
          );
        }, 500);
      } else {
        // Game over
        setGameLocked(true);
        if (timerRef.current) clearInterval(timerRef.current);
        setTimeout(() => setShowGameOver(true), 500);
      }
    }
  };

  const handleDrop = (cellId: string, value: number, sourceCellId?: string) => {
    const updatedCells = cells.map((cell) => {
      // Clear the source cell if dragging from another cell
      if (sourceCellId && cell.id === sourceCellId) {
        return { ...cell, value: null, isCorrect: false, isIncorrect: false };
      }
      // Set the value in the target cell
      if (cell.id === cellId) {
        return { ...cell, value, isCorrect: false, isIncorrect: false };
      }
      return cell;
    });
    setCells(updatedCells);
    setMoves((prev) => prev + 1);
    checkGame(updatedCells);
  };

  const handleDragStart = (e: React.DragEvent, num: number) => {
    e.dataTransfer.setData("text/plain", num.toString());
  };

  const handleCellDragStart = (e: React.DragEvent, cellId: string, value: number) => {
    e.dataTransfer.setData("text/plain", value.toString());
    e.dataTransfer.setData("sourceCellId", cellId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const resetGame = () => {
    setCells(CELL_IDS.map((id) => ({ id, value: null, isCorrect: false, isIncorrect: false })));
    setMoves(0);
    setLives(3);
    setTimer(0);
    setGameLocked(false);
    setShowVictory(false);
    setShowGameOver(false);

    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);
  };

  const usedNumbers = cells
    .filter((c) => c.id !== "empty" && c.value !== null)
    .map((c) => c.value as number);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-4 relative">
      {/* Logo in top left */}
      <img 
        src={logoImage} 
        alt="School Logo" 
        className="absolute top-4 left-4 w-20 h-24 md:w-24 md:h-28 object-contain rounded-3xl bg-white/90 p-2 shadow-lg"
      />
      
      {/* Logo in top right */}
      <img 
        src={logoImage} 
        alt="School Logo" 
        className="absolute top-4 right-4 w-20 h-24 md:w-24 md:h-28 object-contain rounded-3xl bg-white/90 p-2 shadow-lg"
      />
      
      <div className="w-full max-w-2xl space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl md:text-5xl font-bold text-white drop-shadow-lg">
            Number Puzzle
          </h1>
          <p className="text-white/90 text-lg">Place numbers 1-8 in the correct positions</p>
        </div>

        <GameStats timer={timer} moves={moves} lives={lives} />

        <PuzzleGrid
          cells={cells}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragStart={handleCellDragStart}
          gameLocked={gameLocked}
        />

        <NumberPalette
          numbers={[1, 2, 3, 4, 5, 6, 7, 8]}
          usedNumbers={usedNumbers}
          onDragStart={handleDragStart}
          gameLocked={gameLocked}
        />

        <div className="flex justify-center">
          <Button
            onClick={resetGame}
            variant="secondary"
            size="lg"
            className="gap-2"
            data-testid="button-reset"
          >
            <RotateCcw className="w-5 h-5" />
            Reset Game
          </Button>
        </div>
      </div>

      <VictoryModal
        isOpen={showVictory}
        timer={timer}
        moves={moves}
        onPlayAgain={resetGame}
      />

      <GameOverModal isOpen={showGameOver} onTryAgain={resetGame} />
    </div>
  );
}
