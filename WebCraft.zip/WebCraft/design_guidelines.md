# Non-Adjacent Number Puzzle - Design Guidelines

## Design Approach

**Selected Framework:** Material Design with game-optimized adaptations
**Rationale:** Material Design's emphasis on visual feedback, layering, and interactive states aligns perfectly with puzzle game mechanics. We'll adapt its principles for an engaging game experience while maintaining clarity and usability.

**Core Design Principles:**
- Immediate visual feedback for all interactions
- Clear game state communication through hierarchy
- Playful yet polished aesthetic appropriate for puzzle gaming
- Accessibility through high contrast and clear affordances

---

## Typography System

**Primary Font:** 'Poppins' (Google Fonts) - rounded, friendly, highly legible
**Secondary Font:** 'Space Mono' (Google Fonts) - for timer and numerical displays

**Type Scale:**
- Game Title (H1): 3xl-4xl, font-bold, tracking-tight
- Section Headers: xl-2xl, font-semibold
- Game Stats (Timer, Moves, Lives): lg-xl, font-medium, tabular-nums
- Grid Numbers: 2xl-3xl, font-bold
- Draggable Numbers: xl-2xl, font-bold
- Button Text: base-lg, font-medium
- Helper Text: sm-base, font-normal

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16
- Micro spacing (within components): p-2, gap-2
- Standard spacing (between related elements): p-4, gap-4, m-4
- Section spacing: p-8, py-12, gap-8
- Major spacing (page sections): p-16, py-16

**Container Strategy:**
- Game viewport: max-w-4xl mx-auto
- Game board container: Centered with px-4 for mobile safety
- Stats bar: Full width with inner max-w-4xl
- Number palette: Centered with max-w-2xl

**Grid Layout:**
- Game grid: Hexagonal arrangement using CSS Grid
- 3-row structure with offset columns creating diamond/hexagonal effect
- Row 1: 2 empty cells + 6 active cells (cells C-H)
- Responsive sizing: 60px cells on mobile, 80px on tablet, 100px on desktop

---

## Component Library

### Game Header
- Sticky positioning at top (optional shadow on scroll)
- Title with emoji prefix, centered
- Subtle gradient overlay effect for depth

### Stats Bar
- Horizontal flex layout with dividers between stats
- Timer with clock icon, Moves counter, Lives indicator with heart/life icons
- Background: semi-transparent overlay with backdrop blur
- Rounded container with subtle border
- Padding: py-4 px-6
- Icons from Heroicons (outline style)

### Game Grid
- Central focus of layout
- Grid cells with rounded corners (rounded-xl)
- Dashed border treatment for empty cells
- Transition effects on all interactive states
- Drop zones with hover state elevation
- Spacing: gap-3 to gap-4 between cells

### Cell States
- **Empty State:** Dashed border, semi-transparent background, subtle pulsing animation hint
- **Hover State:** Elevated appearance (transform scale 1.05), increased opacity
- **Filled State:** Solid background, number centered, slight depth effect
- **Success State:** Distinct treatment with checkmark icon overlay
- **Fail State:** Shake animation, distinct visual treatment, X icon overlay

### Number Palette
- Horizontal flex wrap layout with gap-3
- Circular number tiles (aspect-square, rounded-full)
- Size: w-14 h-14 on mobile, w-16 h-16 on desktop
- Grab cursor on hover
- Active state: scale-110, slight rotation effect
- Used numbers: reduced opacity (opacity-30), not draggable

### Action Buttons
- Primary action (Reset): Large, prominent, rounded-lg
- Size: px-8 py-3
- Hover state: scale-105, increased shadow
- Icon + text combination
- Positioned below number palette with mt-8

### Modal/Alert Overlays
- Victory screen: Full-screen overlay with backdrop blur
- Stats summary in centered card
- Large celebratory text with emoji
- Confetti animation layer (using canvas-confetti)
- Play Again and Share buttons

---

## Interaction & Animation Guidelines

**Drag and Drop:**
- Smooth 200ms transitions on all state changes
- Drag preview: slightly larger, elevated shadow
- Drop target highlight: border pulse, background brightness increase
- Invalid drop: shake animation (animation-shake)

**Validation Feedback:**
- Success: Fade-in green highlight + scale pulse (300ms)
- Failure: Shake animation (400ms) + red highlight fade-in
- Auto-clear failed cells: 1s delay, fade-out transition

**Timer:**
- Tabular number font for consistent width
- Update without layout shift
- Consider pulse effect on seconds change (subtle)

**Confetti Effect:**
- Trigger on puzzle completion
- Burst from center-bottom (origin: y: 0.7)
- 150-200 particles, 70-degree spread
- Duration: 3000ms

---

## Accessibility Considerations

**Keyboard Navigation:**
- Tab order: Stats → Grid cells (left-to-right, top-to-bottom) → Number palette → Reset button
- Enter/Space to select numbers and place in focused cell
- Arrow keys for grid navigation
- Escape to deselect

**Screen Reader Support:**
- aria-label for grid cells indicating position (e.g., "Cell C, Empty")
- aria-live region for move counter, timer, lives
- Success/failure state announcements
- Clear labels for all interactive elements

**Visual Accessibility:**
- High contrast between background and foreground elements
- Success/fail states distinguishable without color alone (icons + color)
- Minimum touch target: 44x44px (cells meet this at smallest size)
- Focus indicators with 2px solid outline, offset by 2px

---

## Responsive Strategy

**Mobile (< 640px):**
- Single column layout
- Grid cells: 60px
- Number palette: 3-4 per row
- Stats bar: Stack vertically or use abbreviations
- Font sizes: Reduced by one step

**Tablet (640px - 1024px):**
- Grid cells: 80px
- Number palette: 4-5 per row
- Stats bar: Horizontal with full labels

**Desktop (> 1024px):**
- Grid cells: 100px
- Maximum container width engaged
- All spacing at full scale
- Hover effects enabled

---

## Visual Hierarchy

**Primary Focus:** Game grid - largest visual weight, central positioning
**Secondary Focus:** Stats bar - persistent visibility, clear readability
**Tertiary Focus:** Number palette - accessible but subordinate to grid
**Supporting Elements:** Title, reset button - present but not competing

**Z-Index Layers:**
1. Base: Background gradient
2. Level 1: Container backgrounds
3. Level 2: Game grid and numbers
4. Level 3: Dragging elements
5. Level 4: Modals and overlays
6. Level 5: Confetti canvas

---

## Success & Completion States

**Victory Screen:**
- Backdrop blur overlay (backdrop-blur-md)
- Centered card with results (max-w-md)
- Large emoji celebration (text-6xl)
- Stats summary: Time, Moves, Lives remaining
- Call-to-action buttons: "Play Again" (primary), "Share Score" (secondary)
- Social share functionality consideration

**Out of Lives Screen:**
- Similar overlay treatment
- Encouraging message
- Show correct solution option
- Prominent "Try Again" button